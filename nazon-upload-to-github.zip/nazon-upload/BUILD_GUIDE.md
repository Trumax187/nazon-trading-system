# NAZON · Android App — Build Guide

This is your NAZON Daily OS wrapped as a real Android app. Once built and
installed, its reminders fire as true system notifications — even when the app
is fully closed and your phone is locked. That's the whole point of going native.

Everything is done except the final compile, which needs the Android SDK on a
computer (it can't be built inside a chat). You have two ways to finish it.
Option A (cloud) needs no installs. Option B (local) is best if you have a PC.

---

## What's already done for you

- Your latest NAZON HTML is bundled as the app's screen (`www/index.html`).
- A native alarm bridge (`www/native-alarms.js`) schedules every task in your
  day as a real Android notification, and re-arms automatically each time you
  open or resume the app. It also schedules tomorrow, so the chain never breaks.
- The Android project is generated (`android/` folder) with the right
  permissions (exact alarms, notifications, boot-persistence, vibrate).
- Branded gold-"N" launcher icons and a white status-bar icon are generated.
- App name: **NAZON**  ·  App ID: **com.nazon.os**

---

## Option A — Build in the cloud (no installs, easiest)

1. Put this whole `nazon-app` folder into a new GitHub repository
   (github.com → New repository → upload the folder).
2. Go to **https://www.appcircle.io** or **https://expo.dev/eas** or any free
   "Capacitor / Android cloud build" service and connect the repo. A simpler
   route many people use: open the repo in **https://gitpod.io** or
   **GitHub Codespaces**, then run the commands from Option B step 3 inside that
   cloud machine (it already has Java + Android SDK).
3. Download the resulting `app-debug.apk`.
4. Copy it to your phone, tap it, allow "install from unknown sources," install.

If you'd rather not deal with cloud services, Option B is more reliable.

---

## Option B — Build on a computer (most reliable)

### One-time setup
1. Install **Android Studio** (free): https://developer.android.com/studio
   On first launch let it download the Android SDK when prompted.
2. Install **Node.js** (free): https://nodejs.org (the "LTS" version).

### Build the APK
Open a terminal **inside the `nazon-app` folder** and run:

```bash
npm install            # restores Capacitor (one time)
npx cap sync android   # copies the web app into the native project
```

Then either:

**Easiest — through Android Studio:**
```bash
npx cap open android
```
Android Studio opens. Plug in your phone (USB debugging on) and press the green
▶ Run button — it installs straight to your phone. Or use the menu:
**Build → Build Bundle(s) / APK(s) → Build APK(s)**, then click "locate" to find
`app-debug.apk`.

**Or — pure command line:**
```bash
cd android
./gradlew assembleDebug
```
The APK lands at:
`android/app/build/outputs/apk/debug/app-debug.apk`
Copy that to your phone and tap to install.

---

## First run on your phone — IMPORTANT

For background alarms to actually wake you, do this once after installing:

1. Open NAZON, tap **🔔 Enable Reminders**, and **Allow** notifications.
2. Go to **Settings → Apps → NAZON → Notifications** and make sure they're on.
3. Go to **Settings → Apps → NAZON → Alarms & reminders** (Android 12+) and
   allow it to schedule exact alarms.
4. Disable battery optimization for NAZON:
   **Settings → Apps → NAZON → Battery → Unrestricted.**
   (Phones like Xiaomi, Oppo, Tecno, Infinix, Samsung kill background apps
   aggressively — this step is what keeps the 5 AM alarm reliable.)
5. Open the app once a day or two so it can roll the schedule forward. It
   pre-arms today + tomorrow each time, so opening it every morning is plenty.

---

## Making changes later

If you edit the schedule (the HTML), just replace `www/index.html`, then run
`npx cap sync android` and rebuild. Everything else stays the same.

---

## Want it on the Play Store later?

The debug APK above is perfect for personal use. For the Play Store you'd build
a *signed release* (`./gradlew bundleRelease` with a signing key) — tell me when
you get there and I'll walk you through it.
