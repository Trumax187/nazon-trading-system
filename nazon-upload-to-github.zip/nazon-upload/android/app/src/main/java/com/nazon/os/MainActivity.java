package com.nazon.os;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
