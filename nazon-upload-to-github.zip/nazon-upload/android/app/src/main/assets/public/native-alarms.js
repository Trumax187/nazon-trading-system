/* ============================================================
   NAZON · native alarm bridge
   Schedules each day's tasks as REAL Android system notifications
   via @capacitor/local-notifications, so reminders fire even when
   the app is closed and the phone is locked.

   This file is only active inside the native app (Capacitor present).
   In a normal browser it does nothing, so the web/PWA version is
   unaffected.
   ============================================================ */
(function () {
  // Only run inside the native Capacitor shell
  if (!window.Capacitor || !window.Capacitor.isNativePlatform || !window.Capacitor.isNativePlatform()) {
    return;
  }

  const LN = window.Capacitor.Plugins.LocalNotifications;
  const CapApp = window.Capacitor.Plugins.App;
  if (!LN) return;

  // Build today's tasks using the SAME engine already defined in index.html.
  // buildDay(dow) and helpers (toMin, fmt12) are defined there.
  function tasksForDate(date) {
    const dow = date.getDay();
    let day;
    try { day = buildDay(dow); } catch (e) { return []; }
    if (!day || !day.tasks) return [];
    return day.tasks;
  }

  // Convert "HH:MM" today (or a given date) into a JS Date
  function timeToDate(hhmm, baseDate) {
    const [h, m] = hhmm.split(":").map(Number);
    const d = new Date(baseDate);
    d.setHours(h, m, 0, 0);
    return d;
  }

  // Stable small integer id per task time+index (Android needs int ids)
  function idFor(dayOffset, idx) {
    return dayOffset * 100 + idx; // 0..99 slots per day, plenty
  }

  async function ensurePermission() {
    try {
      let perm = await LN.checkPermissions();
      if (perm.display !== 'granted') {
        perm = await LN.requestPermissions();
      }
      return perm.display === 'granted';
    } catch (e) {
      return false;
    }
  }

  // Schedule today's remaining tasks + tomorrow's full set,
  // so the chain keeps going even if the app isn't opened daily.
  async function scheduleAll() {
    const ok = await ensurePermission();
    if (!ok) {
      setStatus("⚠ Allow notifications so NAZON can wake you. Open phone Settings › Apps › NAZON › Notifications.");
      return;
    }

    // Clear anything previously scheduled to avoid duplicates
    try {
      const pending = await LN.getPending();
      if (pending && pending.notifications && pending.notifications.length) {
        await LN.cancel({ notifications: pending.notifications.map(n => ({ id: n.id })) });
      }
    } catch (e) {}

    const now = new Date();
    const toSchedule = [];

    // Day offset 0 = today, 1 = tomorrow (rolling 2-day window)
    for (let off = 0; off <= 1; off++) {
      const base = new Date(now);
      base.setDate(base.getDate() + off);
      const tasks = tasksForDate(base);

      tasks.forEach((t, idx) => {
        const fireAt = timeToDate(t.t, base);
        // skip times already in the past (only relevant for today)
        if (fireAt.getTime() <= now.getTime() + 5000) return;

        const cleanTitle = (t.icon ? t.icon + " " : "") +
          t.task.replace("✅ ", "").replace(/<[^>]*>/g, "");
        const body = t.note ? t.note.replace(/<[^>]*>/g, "") : "NAZON · stay on the plan.";

        toSchedule.push({
          id: idFor(off, idx),
          title: cleanTitle,
          body: body,
          schedule: { at: fireAt, allowWhileIdle: true },
          smallIcon: "ic_stat_nazon",
          channelId: "nazon_alarms",
          ongoing: false,
          autoCancel: true
        });
      });
    }

    if (!toSchedule.length) {
      setStatus("✅ No more reminders today. Tomorrow is already scheduled.");
      return;
    }

    try {
      // Create a high-importance channel first (Android 8+)
      await LN.createChannel({
        id: "nazon_alarms",
        name: "NAZON Reminders",
        description: "Daily plan reminders",
        importance: 5,          // HIGH — makes sound + heads-up
        visibility: 1,
        vibration: true,
        lights: true,
        lightColor: "#c9a84c"
      });
    } catch (e) {}

    try {
      await LN.schedule({ notifications: toSchedule });
      setStatus("✅ " + toSchedule.length + " reminders armed — they'll fire even if NAZON is closed.");
    } catch (e) {
      setStatus("⚠ Couldn't arm reminders: " + (e && e.message ? e.message : e));
    }
  }

  function setStatus(msg) {
    const el = document.getElementById("ctrlStatus");
    if (el) el.textContent = msg;
  }

  // Re-arm whenever the app is opened or resumed (cheap + keeps chain fresh)
  function init() {
    scheduleAll();
    if (CapApp && CapApp.addListener) {
      CapApp.addListener('resume', scheduleAll);
    }
    // Expose a manual re-arm hook (wired to the Enable Reminders button)
    window.nazonArmAlarms = scheduleAll;
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
